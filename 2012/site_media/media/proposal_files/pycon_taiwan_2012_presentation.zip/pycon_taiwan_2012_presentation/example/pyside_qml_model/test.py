#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import codecs
from PySide.QtCore import *
from PySide.QtGui import *
from PySide.QtDeclarative import *

ITEM_FILE = 'items.txt'

## A workaround to alias utf8 encoding to cp65001(Microsoft's utf8)
try:
    codecs.lookup('cp65001')
except:
    def cp65001(name):
        if name.lower() == 'cp65001':
            return codecs.lookup('utf-8')
    codecs.register(cp65001)

class MyModel(QAbstractListModel):
    def __init__(self, parent=None):
        QAbstractListModel.__init__(self, parent)
        self._items = self.loadItems(ITEM_FILE)

    def loadItems(self, filename):
        items = []
        for line in file(filename, 'r'):
            line = line.strip()
            if len(line) == 0:
                continue
            items.append(line)
        return items

    def rowCount(self, parent=QModelIndex()):
        return len(self._items)

    def data(self, index, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            return self._items[index.row()]
        return None

class TestApp(QApplication):
    QML_PATH = ''
    MAIN_QML_FILE = QML_PATH + 'test.qml'
    def __init__(self, *argv, **kwargv):
        """Constuctor."""
        super(TestApp, self).__init__(*argv, **kwargv)
        
        self.view = QDeclarativeView()

        ctx = self.view.rootContext()
        self.exampleModel = MyModel()
        ctx.setContextProperty("exampleModel", self.exampleModel) 

        self.view.setResizeMode(QDeclarativeView.SizeRootObjectToView)
        self.view.setSource(QUrl(self.MAIN_QML_FILE))               

        self.view.show()

        self.connect(self.view.engine(), SIGNAL('quit()'), self, SLOT('quit()')) 

if __name__ == '__main__':
    TestApp(sys.argv).exec_()