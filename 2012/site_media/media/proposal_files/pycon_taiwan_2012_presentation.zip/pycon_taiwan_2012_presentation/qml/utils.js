/**
 * Method to help change state.
 */
function changeState(stateContainer, newState) {
	var stateName;
	if (typeof(newState) == "string")
	{
		stateName = newState;
		newState = getStateIdx(stateContainer, stateName);
		if (newState < 0)
		{
			return;
		}
	}
	else if (typeof(newState) == "number")
	{
		if (newState != 0)
		{
			newState = stateContainer.currStateIdx + newState
		}		
		if (newState >= stateContainer.states.length)
		{
			newState = stateContainer.states.length - 1;
		}	
		else if (newState < 0)
		{
			newState = 0;
		}		
		stateName = stateContainer.states[newState].name;
	}
	else
	{
		console.log("Unknown state!")
		return;
	}
	if (stateContainer.state != stateName)
	{
		console.log("State changed from \"" + stateContainer.state + "\" to \"" + stateName + "\"")
	}	
	stateContainer.state = stateName;
	stateContainer.currStateIdx = newState;	
}

/**
 * Get the index of state.
 */
function getStateIdx(stateContainer, stateName)
{
	for(var i = 0; i < stateContainer.states.length; ++i)
	{
		if (stateName == stateContainer.states[i])
		{
			return i;
		}
	}
	return -1;
}

/**
 * Check if its last state.
 */
function isLastState(stateContainer)
{	
	if (stateContainer == null)
	{
		return false;
	}
	return (
		stateContainer.state == 
		stateContainer.states[stateContainer.states.length - 1].name);
}