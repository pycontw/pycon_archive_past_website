#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import codecs
from PySide.QtCore import *
from PySide.QtGui import *
from PySide.QtDeclarative import *

## Enable/disable full screen mode.
FullScreen = False

## Specify the desktop to be display.
DisplayDesktop = 2

## A workaround to alias utf8 encoding to cp65001(Microsoft's utf8)
try:
    codecs.lookup('cp65001')
except:
    def cp65001(name):
        if name.lower() == 'cp65001':
            return codecs.lookup('utf-8')
    codecs.register(cp65001)

class PresentationApp(QApplication):
    """Application instance for presentation."""
    QML_PATH = 'qml/'
    MAIN_QML_FILE = QML_PATH + 'Presentation.qml'
    def __init__(self, *argv, **kwargv):
        """Constuctor."""
        super(PresentationApp, self).__init__(*argv, **kwargv)
        
        desktop = self.desktop()
        screenIdx = 1 if DisplayDesktop > desktop.screenCount() else DisplayDesktop
        parentScreen = None if desktop.isVirtualDesktop() else desktop.screen(screenIdx)
        self.view = QDeclarativeView(parentScreen)
        if desktop.isVirtualDesktop():
            origin = desktop.screen(screenIdx).pos()            
            self.view.move(origin)

        ctx = self.view.rootContext()
        self.exampleModel = self.createModelData()
        ctx.setContextProperty("exampleModel", self.exampleModel) 

        self.view.setResizeMode(QDeclarativeView.SizeRootObjectToView)
        self.view.setSource(QUrl(self.MAIN_QML_FILE))               

        if FullScreen:
            self.view.showFullScreen()
        else:
            self.view.show()

        self.connect(self.view.engine(), SIGNAL('quit()'), self, SLOT('quit()')) 
        self.view.rootObject().onScenarioChanged.connect(self.onScenarioChanged)

    def createModelData(self):
        """Create a model data."""
        stringList = []
        stringList.append("Taiwan#01")
        stringList.append("Taiwan#02")
        stringList.append("Taiwan#03")
        stringList.append("Taiwan#04")
        stringList.append("Taiwan#05")
        stringList.append("Taiwan#06")
        stringList.append("Taiwan#07")
        stringList.append("Taiwan#08")
        stringList.append("Taiwan#09")
        stringList.append("Taiwan#10")
        stringList.append("Taiwan#11")
        stringList.append("Taiwan#12")
        stringList.append("Taiwan#13")
        stringList.append("Taiwan#14")
        stringList.append("Taiwan#15")
        stringList.append("Taiwan#16")
        stringList.append("Taiwan#17")
        stringList.append("Taiwan#18")
        stringList.append("Taiwan#19")
        stringList.append("Taiwan#20")

        model = QStringListModel(stringList)
        #model.setStringList(stringList)
        return model

    @Slot()
    def onScenarioChanged(self, scenarioId):
        """The slot to receive onScenarioChanged signal."""
        print "Screnario Id: %s" % scenarioId
        return

__version__ = 'PySide/QtQuick Presentation v1.0.0.0'
__author__ = 'Gary W. Lee <garywlee@gmail.com>'

def main():
    """Main entry of program."""
    PresentationApp(sys.argv).exec_()

if __name__ == '__main__':
    sys.exit(main())